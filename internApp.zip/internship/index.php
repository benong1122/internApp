<?php 
  session_start();
  require_once 'core/init.php';
  include 'includes/header.php'; 
?>

<?php 
  $sql = "SELECT * FROM internships WHERE deleted=0";
  $internships = $db->query($sql);
?>
<main>
<div class="image-section">
    <div class="overlay-text">
        <h1>INTERNSHIP MANAGEMENT</h1>
        <a href="#list-of-internships" class="explore-btn">Explore</a>
    </div>
</div>

<div class="buttons-section text-center">
    <a href="register.php" class="btn btn-primary m-3 btn-lg square-button">
        <i class="fas fa-user-plus fa-3x"></i><br>Student Register
    </a>
    <a href="login.php" class="btn btn-secondary m-3 btn-lg square-button">
        <i class="fas fa-sign-in-alt fa-3x"></i><br>Student Login
    </a>
    <a href="employer/register.php" class="btn btn-primary m-3 btn-lg square-button">
        <i class="fas fa-user-plus fa-3x"></i><br>Employee Register
    </a>
    <a href="employer/login.php" class="btn btn-secondary m-3 btn-lg square-button">
        <i class="fas fa-sign-in-alt fa-3x"></i><br>Employee Login
    </a>
</div>
<hr class="grey-line"> <!-- Grey line separator -->

<style>
    .image-section {
        background: url('education-wallpaper-preview.jpg') no-repeat center center fixed;
        background-size: cover;
        height: 100vh;
        position: relative;
        text-align: center;
    }

    .image-section h1 {
      font-size: 160px;
      color: #fff;
      font-weight: 600;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }


    .image-section a {
        text-decoration: none;
        display: inline-block;
        color: #fff;
        font-size: 24px;
        border: 2px solid #fff;
        padding: 14px 70px;
        border-radius: 50px;
        margin-top: 20px;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .overlay-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        padding: 20px;
        border-radius: 10px;
        color: transparent;
        background-clip: text;
    }

    .grey-line {
        border-top: 2px solid grey;
        margin: 20px 0;
    }

    .buttons-section {
      padding-top: 30px;
      padding-bottom: 30px;
    }

    .text-center {
      font-weight: bold;
    }

    .card-header {
        background-color: #FFA500; 
        color: #fff; 
    }

    .card-body {
        background-color: #F8F9FA;
    }
</style>

  <h3 id="list-of-internships" class="text-center p-3">LIST OF INTERNSHIPS</h3>
  <div class="container-fluid row">
    <!-- List of Internships -->
    <?php while($internship = mysqli_fetch_assoc($internships)): ?>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          <h2 class="p-2 text-center card-title"><?=$internship['nameOfCompany'];?></h2>
        </div>
        <div class="card-body">
          <h4 class="p-2 h4-responsive float-left"><?=$internship['category'];?></h4>
          <h5 class="p-2 h5-responsive float-right"><b>Location: </b><?=$internship['location'];?></h5>
          <table class="table table-bordered">
            <thead>
              <th>Duration</th>
              <th>Stipend</th>
              <th>Posted On</th>
              <th>Apply By</th>
              <th>Available Positions</th>
            </thead>
            <tbody>
              <tr>
                <td><?=$internship['duration'];?> months</td>
                <td>&#8377; <?=$internship['stipend'];?></td>
                <td><?=$internship['postedOn'];?></td>
                <td><?=$internship['applyBy'];?></td>
                <td><?=$internship['positions'];?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="card-footer">
          <a href="internship.php?internship=<?=$internship['id'];?>" class="btn btn-success btn-black waves-effect z-depth-0">View Details</a>
        </div>
      </div>
    </div>
    <?php endwhile;?>
  </div>
  <br>
</main>
<?php include 'includes/footer.php'; ?>