<?php
	session_start();
	require_once '../core/init.php';
	include('includes/header.php');
?>

<?php 
	if(!isset($_SESSION['email'])){
      echo "<script>window.open('login.php','_self')</script>";
    }else{
?>

	<main>
		<div class="image-section">
    		<div class="overlay-text">
        		<h1>Welcome!</h1>
        		<a href="internship.php" class="explore-btn">Internship</a>
				<a href="myaccount.php" class="explore-btn">My Account</a>
    		</div>
		</div>    
		
<style>
    .image-section {
        background: url('../education-wallpaper-preview.jpg') no-repeat center center fixed;
        background-size: cover;
        height: 100vh;
        position: relative;
        text-align: center;
    }

    .image-section h1 {
      font-size: 160px;
      color: #fff;
      font-weight: 600;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }


    .image-section a {
        text-decoration: none;
        display: inline-block;
        color: #fff;
        font-size: 24px;
        border: 2px solid #fff;
        padding: 14px 70px;
        border-radius: 50px;
        margin-top: 20px;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .overlay-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        padding: 20px;
        border-radius: 10px;
        color: transparent;
        background-clip: text;
    }

    .grey-line {
        border-top: 2px solid grey;
        margin: 20px 0;
    }

    .buttons-section {
      padding-top: 30px;
      padding-bottom: 30px;
    }

    .text-center {
      font-weight: bold;
    }

    .card-header {
        background-color: #FFA500; 
        color: #fff; 
    }

    .card-body {
        background-color: #F8F9FA;
    }
</style>

	</main>
<?php
	include 'includes/footer.php';
?>

<?php } ?>